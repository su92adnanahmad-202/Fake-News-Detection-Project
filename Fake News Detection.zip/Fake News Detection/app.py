import os
import re
import json
import joblib
import nltk
from flask import Flask, request, jsonify, render_template
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

nltk.download('stopwords', quiet=True)
nltk.download('wordnet', quiet=True)
nltk.download('omw-1.4', quiet=True)

app = Flask(__name__)

# ── Load model & vectorizer ───────────────────────────────────────────────────
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'fake_news_pac_model.joblib')
TFIDF_PATH = os.path.join(os.path.dirname(__file__), 'tfidf_vectorizer.joblib')

model = None
tfidf = None

if os.path.exists(MODEL_PATH) and os.path.exists(TFIDF_PATH):
    model = joblib.load(MODEL_PATH)
    tfidf = joblib.load(TFIDF_PATH)
    print("✓ Model and vectorizer loaded.")
else:
    print("⚠ Model files not found. Place fake_news_pac_model.joblib and tfidf_vectorizer.joblib in the app directory.")

# ── Text cleaning (mirrors Cell 1 logic) ────────────────────────────────────
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

def clean_text(text: str) -> str:
    text = str(text).lower()
    text = re.sub(r'https?://\S+|www\.\S+', '', text)
    text = re.sub(r'[^a-z\s]', '', text)
    tokens = text.split()
    tokens = [lemmatizer.lemmatize(w) for w in tokens
              if w not in stop_words and len(w) > 2]
    return ' '.join(tokens)

# ── Routes ────────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    text = data.get('text', '').strip()

    if not text:
        return jsonify({'error': 'No text provided'}), 400

    if model is None or tfidf is None:
        return jsonify({'error': 'Model not loaded. Please add model files.'}), 503

    cleaned = clean_text(text)
    vector = tfidf.transform([cleaned])
    pred = model.predict(vector)[0]

    # Get decision score for confidence proxy
    score = model.decision_function(vector)[0]
    # Map score to a 50–99 confidence range
    import math
    raw_conf = 1 / (1 + math.exp(-abs(float(score))))  # sigmoid
    confidence = int(50 + raw_conf * 49)

    verdict = 'FAKE' if pred == 1 else 'REAL'
    reason = (
        'High-confidence indicators of fabricated content detected.'
        if verdict == 'FAKE'
        else 'Text patterns consistent with credible reporting.'
    )

    return jsonify({
        'verdict': verdict,
        'confidence': confidence,
        'reason': reason,
        'cleaned_length': len(cleaned.split())
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
